A.R.E.S. — Advanced Roster Execution System
LAMP Server Deployment Package
══════════════════════════════════════════════

REQUIREMENTS
  - Ubuntu 20.04 / 22.04 / 24.04 (or any Debian-based distro)
  - Apache2 (already installed on your LAMP stack)
  - Node.js 24 (installer will add if missing)
  - PostgreSQL (installer will add if missing)

QUICK INSTALL (automated)
  sudo bash deploy/setup.sh

  The script will:
    1. Install Node.js 24 and PostgreSQL (if not present)
    2. Create the "ares" database and generate a secure password
    3. Copy app files to /opt/ares
    4. Apply the database schema
    5. Configure Apache as a reverse proxy on port 80
    6. Install and start the "ares" systemd service

MANUAL INSTALL
  See MANUAL_INSTALL.txt for step-by-step instructions.

AFTER INSTALL
  - Default login:  admin@admin.local  /  Password%1
  - CHANGE THE ADMIN PASSWORD immediately after first login
  - Enable HTTPS:   sudo apt install certbot python3-certbot-apache
                    sudo certbot --apache -d your-domain.com

MANAGING THE SERVICE
  sudo systemctl status ares     # Check status
  sudo systemctl restart ares    # Restart
  sudo journalctl -u ares -f     # Live logs

PACKAGE CONTENTS
  server/index.cjs               Node.js API server (self-contained bundle)
  public/                        Built frontend static files
  migrations/0000_initial_schema.sql  Full database schema
  deploy/apache-ares.conf        Apache virtual host config
  deploy/ares.service            systemd service unit
  deploy/setup.sh                Automated installer
  .env.example                   Environment variable template
